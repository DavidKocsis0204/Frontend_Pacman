let palya=document.querySelector('#palya');
let mapgrid = [
    /*
    0: szabad terület;
    1: fal
    2: nagy pont
    3: pont
    4: pac-man
    5: kapu
     */
    [0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0],
    [0,1,3,3,3,3,3,3,3,3,1,3,3,3,3,3,3,3,3,1,0],
    [0,1,2,1,1,3,1,1,1,3,1,3,1,1,1,3,1,1,2,1,0],
    [0,1,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,1,0],
    [0,1,3,1,1,3,1,3,1,1,1,1,1,3,1,3,1,1,3,1,0],
    [0,1,3,3,3,3,1,3,3,3,1,3,3,3,1,3,3,3,3,1,0],
    [0,1,1,1,1,3,1,1,1,0,1,0,1,1,1,3,1,1,1,1,0],
    [0,0,0,0,1,3,1,0,0,0,0,0,0,0,1,3,1,0,0,0,0],
    [1,1,1,1,1,3,1,0,1,1,5,1,1,0,1,3,1,1,1,1,1],
    [0,0,0,0,0,3,0,0,1,0,0,0,1,0,0,3,0,0,0,0,0],
    [1,1,1,1,1,3,1,0,1,1,1,1,1,0,1,3,1,1,1,1,1],
    [0,0,0,0,1,3,1,0,0,0,0,0,0,0,1,3,1,0,0,0,0],
    [0,1,1,1,1,3,1,0,1,1,1,1,1,0,1,3,1,1,1,1,0],
    [0,1,3,3,3,3,3,3,3,3,1,3,3,3,3,3,3,3,3,1,0],
    [0,1,3,1,1,3,1,1,1,3,1,3,1,1,1,3,1,1,3,1,0],
    [0,1,2,3,1,3,3,3,3,3,4,3,3,3,3,3,1,3,2,1,0],
    [0,1,1,3,1,3,1,3,1,1,1,1,1,3,1,3,1,3,1,1,0],
    [0,1,3,3,3,3,1,3,3,3,1,3,3,3,1,3,3,3,3,1,0],
    [0,1,3,1,1,1,1,1,1,3,1,3,1,1,1,1,1,1,3,1,0],
    [0,1,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,1,0],
    [0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0]];
GameMapGenerate();


function GameMapGenerate(){
    for (let i = 0; i < mapgrid.length; i++) {
        let element=document.createElement('tr');
        for (let j = 0; j < mapgrid[0].length; j++) {
            if(mapgrid[i][j]==0) element.innerHTML+=`<td class="fekete"><div class="fekete"></div></td>`;
            if(mapgrid[i][j]==1) element.innerHTML+=`<td class="kek"></td>`;
            if(mapgrid[i][j]==2) element.innerHTML+=`<td class="fekete"><div class="nagypont"></div></td>`;
            if(mapgrid[i][j]==3) element.innerHTML+=`<td class="fekete"><div class="kispont"></div></td>`;
            if(mapgrid[i][j]==4) element.innerHTML+=`<td class="fekete"><div class="pacman"></div></td>`;
            if(mapgrid[i][j]==5) element.innerHTML+=`<td class="fekete kapu"></td>`;
        }
        palya.append(element);
    }
};

function WDown(){
    let pacmanCurrentLocation=0;    //ebben a változóban tároljuk pacman koordinátáit a játéktéren
}

function PacmanSearch(){
    let x,y;
    for (let i = 0; i < mapgrid.length; i++) {  //vissza adja pacman helyét az y tengelyen 
        y=lepteto(mapgrid[i]);
        if(y==4) x=i;
    }
                    //itt kell visszaadni pacman jelenlegi helyét 
}

function lepteto(i){    // vissza adja pacman hejét az x tengelyen
    for (let j = 0; j < mapgrid[j].length; y++) {
        if(mapgrid[i][j]==4) return j;
    }
    return -1;
}